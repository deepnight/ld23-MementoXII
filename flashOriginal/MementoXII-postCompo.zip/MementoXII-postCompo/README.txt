MementoXII-postCompo (original Flash version) 
------------------------------------------------

Run the "Play MementoXII-postCompo" to start the game. 
Visit https://deepnight.net for more. 

Note: this script will do nothing than opening the SWF file using the embedded Flash Projector executable (renamed to BIN to avoid some confusions). 
