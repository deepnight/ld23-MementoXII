------------------------------------------------
MementoXII-extended (original Flash version) 
https://deepnight.net 
------------------------------------------------

Run "Play MementoXII-extended" to start the game :) 

Note: this script will do nothing more than opening the SWF file using the embedded Flash Projector executable (renamed to BIN to avoid some confusions). 
